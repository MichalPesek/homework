<?php

define("URL", "http://knihypesek.kvalitne.cz");
define("URL_DIR", "/");
define("APP_DIR", "app/");
define("DATA_DIR", "data/");
define("TMPLT_DIR", "templates/");

/*
define("URL", "http://www");
define("URL_DIR", "/php-examples/url-router/05-oop/");
define("APP_DIR", "app/");
define("DATA_DIR", "data/");
define("TMPLT_DIR", "templates/");
*/
